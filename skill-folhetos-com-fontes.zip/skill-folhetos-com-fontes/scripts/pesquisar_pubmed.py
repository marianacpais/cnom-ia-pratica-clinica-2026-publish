#!/usr/bin/env python3
"""Pesquisa no PubMed (E-utilities do NCBI) os artigos dos últimos N dias.

Determinístico: a mesma pesquisa, no mesmo dia, dá a mesma lista. Só biblioteca padrão.
Uso: python3 pesquisar_pubmed.py "termos" [--dias 7] [--max 10]
"""
import argparse, json, sys, urllib.parse, urllib.request
import xml.etree.ElementTree as ET

BASE = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"


def get(url):
    with urllib.request.urlopen(url, timeout=30) as r:
        return r.read()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("termos")
    ap.add_argument("--dias", type=int, default=7)
    ap.add_argument("--max", type=int, default=10)
    a = ap.parse_args()
    q = urllib.parse.urlencode({"db": "pubmed", "term": a.termos, "reldate": a.dias, "datetype": "edat",
                                "retmode": "json", "retmax": a.max, "sort": "pub_date"})
    s = json.loads(get(BASE + "esearch.fcgi?" + q))["esearchresult"]
    ids = s.get("idlist", [])
    out = {"pesquisa": a.termos, "dias": a.dias, "total_encontrado": int(s.get("count", 0)), "artigos": []}
    if ids:
        x = ET.fromstring(get(BASE + "efetch.fcgi?" + urllib.parse.urlencode({"db": "pubmed", "id": ",".join(ids), "retmode": "xml"})))
        for art in x.findall(".//PubmedArticle"):
            pmid = art.findtext(".//PMID")
            abstract = " ".join("".join(t.itertext()) for t in art.findall(".//Abstract/AbstractText"))
            d = art.find(".//ArticleDate")
            if d is None:
                d = art.find(".//PubDate")
            data = "-".join(filter(None, [d.findtext("Year"), d.findtext("Month"), d.findtext("Day")])) if d is not None else ""
            out["artigos"].append({
                "pmid": pmid,
                "titulo": "".join(art.find(".//ArticleTitle").itertext()) if art.find(".//ArticleTitle") is not None else "",
                "revista": art.findtext(".//Journal/Title") or "",
                "data": data,
                "tipos": [t.text for t in art.findall(".//PublicationType")],
                "abstract": abstract,
                "link": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
            })
    json.dump(out, sys.stdout, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
