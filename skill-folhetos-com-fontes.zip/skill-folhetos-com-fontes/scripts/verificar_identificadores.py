#!/usr/bin/env python3
"""Procura identificadores óbvios num texto, ANTES de ele ir para um modelo de linguagem.

Determinístico e local: corre no computador, não envia nada. Só apanha padrões (números,
datas, contactos). Não apanha o resto (profissão, terra, pormenores raros): isso exige juízo.
Uso: python3 verificar_identificadores.py ficheiro.txt   (ou texto pela entrada padrão)
"""
import re, sys

PADROES = {
    "número de utente / NIF (9 dígitos)": r"\b\d{3}\s?\d{3}\s?\d{3}\b",
    "data": r"\b\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}\b",
    "telefone": r"(?:\+351\s?)?\b[29]\d{2}\s?\d{3}\s?\d{3}\b",
    "email": r"\b[\w.+-]+@[\w-]+\.[\w.]+\b",
    "código postal": r"\b\d{4}-\d{3}\b",
}


def main():
    texto = open(sys.argv[1], encoding="utf-8").read() if len(sys.argv) > 1 else sys.stdin.read()
    achados = [(nome, m.group()) for nome, p in PADROES.items() for m in re.finditer(p, texto)]
    if achados:
        print("PARAR: encontrei identificadores. Retire-os antes de continuar:")
        for nome, valor in achados:
            print(f"  - {nome}: {valor}")
        sys.exit(1)
    print("Não encontrei padrões óbvios. Atenção: profissão, terra, datas por extenso e pormenores raros também identificam.")


if __name__ == "__main__":
    main()
