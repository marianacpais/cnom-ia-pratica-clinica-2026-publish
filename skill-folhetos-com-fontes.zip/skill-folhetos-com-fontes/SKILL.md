---
name: folhetos-com-fontes
description: Do tema ao folheto e ao email, com fontes. Pesquisa a evidência recente no PubMed com citações verificáveis, faz um folheto em linguagem simples a partir dessas fontes e escreve o rascunho do email que o acompanha. Usar quando o médico pedir "o que saiu sobre", "faz um folheto", "explica de forma simples", "prepara o email para mandar o folheto". Nunca responde de memória e nunca trabalha com dados que identifiquem alguém.
---

# Folhetos com fontes

Skill de demonstração do workshop "Inteligência Artificial na Prática Clínica" (29.º Congresso Nacional da Ordem dos Médicos, 12/11/2026). É o exemplo da sessão guardado: cada regra aqui apareceu num passo da demonstração.

## 0. Antes de tudo: dados pessoais

- Se o pedido trouxer texto de um processo clínico, um diário de consulta ou qualquer dado sobre uma pessoa concreta, correr primeiro `scripts/verificar_identificadores.py` sobre esse texto.
- Se o script encontrar identificadores (números de utente, NIF, datas, telefones, emails, códigos postais), **parar** e pedir uma versão sem eles.
- Mesmo sem identificadores encontrados, lembrar que o script só apanha padrões: profissão, terra, datas por extenso e pormenores raros também identificam. Propor personalizar só com meia dúzia de campos escolhidos pelo médico (faixa etária, dúvida principal, nível de leitura).
- Nunca usar dados de saúde de alguém numa conta pessoal: só em ferramentas aprovadas pela instituição.

## 1. Pesquisar com fontes verificáveis

- **Nunca citar de memória.** As referências vêm da pesquisa feita agora, com `scripts/pesquisar_pubmed.py` (ou, sem execução de código com internet, a pesquisa web restrita a `pubmed.ncbi.nlm.nih.gov`).
- **Mostrar a pesquisa exata**, para se poder repetir. Preferir termos MeSH: em texto livre aparecem artigos ao lado.
- Para cada artigo: título, revista, data, tipo de estudo, PMID e link. Resumo de três linhas, só a partir do abstract, identificado como automático.
- **Nenhuma afirmação sem prova à vista:** para o que for para o folheto, citar o excerto do abstract que a sustenta.
- **O que não se encontrou também é resultado:** dizer o período, a pesquisa e o que ficou de fora.

```bash
python3 scripts/pesquisar_pubmed.py '"Glucagon-Like Peptide-1 Receptor Agonists"[MeSH] AND obesity' --dias 7 --max 10
```

## 2. Fazer o folheto

- Linguagem simples, frases curtas, sem termos técnicos (ou explicados), uma página.
- Só o que está nas fontes da secção 1. Nada de "estudos mostram" sem a fonte; nada de exagerar ao simplificar ("cura", "sem efeitos secundários").
- **Informação geral, nunca recomendação a uma pessoa concreta** ("fale com o seu médico antes de começar ou parar qualquer medicamento").
- Datado ("atualizado a …") e com as fontes no fim.

## 3. Escrever o email que o acompanha

- **Rascunho, nunca enviado:** quem envia é o médico, depois de rever.
- Assunto curto e claro (ex.: "Informação sobre o tratamento de que falámos").
- Corpo curto: para que serve o folheto, onde estão as fontes, a quem perguntar se tiver dúvidas.
- Sem dados clínicos de ninguém no corpo do email.
- Sem pontas soltas ("a confirmar", "[?]").

## 4. Fecho

Terminar sempre com o que foi pesquisado, o que ficou de fora e o que o médico deve confirmar antes de entregar.
