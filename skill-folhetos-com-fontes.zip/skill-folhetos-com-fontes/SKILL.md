---
name: folhetos-com-fontes
description: Do tema ao folheto e ao email, com fontes. Pesquisa a evidência recente no PubMed com citações verificáveis, faz um folheto em linguagem simples a partir dessas fontes e escreve o rascunho do email que o acompanha. Usar quando pedirem "o que saiu sobre", "faz um folheto", "explica de forma simples", "prepara o email para mandar o folheto". Nunca responde de memória. Só para informação geral sobre um tema.
---

# Folhetos com fontes

Skill de demonstração do workshop "Inteligência Artificial na Prática Clínica" (29.º Congresso Nacional da Ordem dos Médicos, 12/11/2026). É o exemplo da sessão guardado: cada regra aqui apareceu num passo da demonstração.

Serve para informação geral sobre um tema, para quem nos pergunta. Não é para personalizar a partir de dados de ninguém.

## 1. Pesquisar com fontes verificáveis

- **Nunca citar de memória.** As referências vêm da pesquisa feita agora, com `scripts/pesquisar_pubmed.py` (ou, sem execução de código com internet, a pesquisa web restrita a `pubmed.ncbi.nlm.nih.gov`).
- **Mostrar a pesquisa exata**, para se poder repetir. Preferir termos MeSH, porque em texto livre aparecem artigos ao lado.
- Para cada artigo: título, revista, data, tipo de estudo, PMID e link. Resumo de três linhas, só a partir do abstract, identificado como automático.
- **Nenhuma afirmação sem prova à vista.** Para o que for para o folheto, citar o excerto do abstract que a sustenta.
- **O que não se encontrou também é resultado.** Dizer o período, a pesquisa e o que ficou de fora.

```bash
python3 scripts/pesquisar_pubmed.py '"Glucagon-Like Peptide-1 Receptor Agonists"[MeSH] AND obesity' --dias 7 --max 10
```

## 2. Fazer o folheto

- Linguagem simples, frases curtas, sem termos técnicos (ou explicados), uma página.
- Só o que está nas fontes do passo 1. Nada de "estudos mostram" sem a fonte, nada de exagerar ao simplificar ("cura", "sem efeitos secundários").
- **Informação geral, nunca recomendação a uma pessoa concreta** ("fale com a sua equipa de saúde antes de começar ou parar qualquer medicamento").
- Datado ("atualizado a …") e com as fontes no fim.

## 3. Escrever o email que o acompanha

- **Rascunho, nunca enviado.** Quem envia é quem pediu, depois de rever.
- Assunto curto e claro (ex.: "Informação sobre o tratamento de que falámos").
- Corpo curto: para que serve o folheto, onde estão as fontes, a quem perguntar se houver dúvidas.
- Sem pontas soltas ("a confirmar", "[?]").

## 4. Fecho

Terminar sempre com o que foi pesquisado, o que ficou de fora e o que convém confirmar antes de entregar.
